Introduction:
This is an IDL program. To run it, you need the following libs and data files:

HEALPix      (http://healpix.jpl.nasa.gov/, or http://sourceforge.net/projects/healpix/ for direct download), 
Astrolib     (required by HEALPix, http://idlastro.gsfc.nasa.gov/ftp/astron.dir.tar.gz), 
WMAP_IDL_Pro (http://lambda.gsfc.nasa.gov/data/map/dr4/software/widl_v4/wmap_IDLpro_v40.tar.gz)
For all libs, only the IDL pro are needed.

The required data files are the WMAP3 calibrated, filtered TOD (about 94GB):
http://lambda.gsfc.nasa.gov/product/map/dr2/tod_fcal_get.cfm

You also need an 64-bit fortran90 compiler, the GNU gfortran works fine.
This program can also work without a fortran compiler, but will cost ten 
times time and twice memory to finish the same job.

This program must be run on a 64-bit machine, but it doesn't require a 
multi-processor environment: the speed is mainly limited by the memory 
bandwidth. This program is efficient: If the fortran plug-in works, it 
can finish 80-round, one-band, single-year map-making within 50(K-band) 
to 120(W-band) minutes on a general 4-core machine. If the ".bin" cache 
files are not deleted, then the next time, the 80-round map-making can 
be finished within 10(K-band) to 25(W-band) minutes.



Directions:
1, put the 3yr processing mask and the WMAP file map_los.fits into one 
    directory (The param "wmapdir").
2, download and put the WMAP3 calibrated-filtered TOD (.fits) into another
    directory (The param "tod_dir"), make sure it contains nothing else.
3, make a new directory, which will be the working directory (the param 
    "working_dir"). It should has at least 20GB free disk space (for 1 
    band, single-year).
4, make sure that you machine is a 64-bit one, and you have enough free 
    memory (in single-year case, 3GB for K-band, 6GB for W-band). 8GB is 
    recommended. I don't recommend making all-year maps, because it will 
    need 40GB or more free memory.
5, compile the file loop.f90 to make an shared object file. I used this 
    command: gfortran -shared -fPIC -O3 loop.f90 -o loop.so
6, modify mapmaking.pro (just at the beginning) for:
    tod_dir 
    working_dir
    wmapdir
    maskfile
    rounds
    so_file (set it to 0 if you fail to make the fortran code work)
7, compile tod_unpack_quick.pro and mapmaking.pro
8, run the program. You can follow the examples at the begining of mapmaking.pro



Tips:
1, Single year map-making is strongly recommended for two reasons: the 
    CMB power spectrum is derived from single year maps, and single year 
    map-making is much faster than all-year map-making (unless you have 
    more than 40GB free memory on your machine)
2, If you fail to work with the fortan plug-in, then you can try setting 
    so_file=0, this forces the program to work purely in IDL, but would 
    be VERY VERY slow.
3, This program is written for WMAP3 TOD. It can also work with 
    WMAP5/WMAP7 TOD, but strictly speaking, for WMAP5/WMAP7, you should 
    change some of the parameters and add a 1/f filtering module. However,
    these actually bring only small difference.
4, Some crucial places in the program are marked by a line of semicolons:
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

5, The keyword "wmap_mode" is used to produce CMB maps with the WMAP 
    offset setting. You can trace this keyword in tod_unpack_quick.pro 
    to see all the induced differences. Note that mapmaking.pro is unaffected
    by this keyword, because it just accepts the output of tod_unpack_quick.pro
    as input.